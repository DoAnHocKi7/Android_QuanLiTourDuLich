﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ClassLibrary1
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void tOURBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tOURBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.qlTourDuLichDataSet);

            

        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
