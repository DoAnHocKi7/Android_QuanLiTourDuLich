﻿namespace FrmMain {
    
    
    public partial class DataSet1 {
    }
}

namespace FrmMain.DataSet1TableAdapters {
    
    
    public partial class TOURTableAdapter {
    }
}
