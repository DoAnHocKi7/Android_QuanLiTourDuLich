﻿namespace FrmMain
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barHeaderItem1 = new DevExpress.XtraBars.BarHeaderItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.ribbonGalleryBarItem1 = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.barListItem1 = new DevExpress.XtraBars.BarListItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.barMdiChildrenListItem1 = new DevExpress.XtraBars.BarMdiChildrenListItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.btnNV = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhgBan = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhanQuyen = new DevExpress.XtraBars.BarButtonItem();
            this.btnDSTour = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageCategory1 = new DevExpress.XtraBars.Ribbon.RibbonPageCategory();
            this.frmMain_QLHT = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.frmMain_HThong = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmMain_PQ = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmPQ = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.FrmMain_QLTour = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.frmQLTour = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLCTTour = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLTKTour_Ycau = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLTKTour_CoSan = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLKS = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLHDV = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmMain_QLKDTour = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.frmQLTour_KhachLe = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLKH = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLHD = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmMain_DoanhThu = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.frmQLDT_TheoThang = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmQLDT_TheoNam = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.frmMain_Report = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.barHeaderItem1,
            this.barStaticItem1,
            this.barButtonItem1,
            this.barSubItem1,
            this.ribbonGalleryBarItem1,
            this.barListItem1,
            this.barButtonGroup1,
            this.barSubItem2,
            this.barMdiChildrenListItem1,
            this.barStaticItem2,
            this.btnNV,
            this.btnPhgBan,
            this.btnPhanQuyen,
            this.btnDSTour,
            this.barButtonItem2,
            this.barButtonItem3});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 17;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.PageCategories.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageCategory[] {
            this.ribbonPageCategory1});
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.frmMain_QLHT,
            this.FrmMain_QLTour,
            this.frmMain_QLKDTour,
            this.frmMain_DoanhThu,
            this.frmMain_Report});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2010;
            this.ribbonControl1.Size = new System.Drawing.Size(979, 162);
            this.ribbonControl1.Click += new System.EventHandler(this.ribbonControl1_Click);
            // 
            // barHeaderItem1
            // 
            this.barHeaderItem1.Caption = "barHeaderItem1";
            this.barHeaderItem1.Id = 1;
            this.barHeaderItem1.Name = "barHeaderItem1";
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "barStaticItem1";
            this.barStaticItem1.Id = 2;
            this.barStaticItem1.Name = "barStaticItem1";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 3;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "barSubItem1";
            this.barSubItem1.Id = 4;
            this.barSubItem1.Name = "barSubItem1";
            // 
            // ribbonGalleryBarItem1
            // 
            this.ribbonGalleryBarItem1.Caption = "ribbonGalleryBarItem1";
            this.ribbonGalleryBarItem1.Id = 5;
            this.ribbonGalleryBarItem1.Name = "ribbonGalleryBarItem1";
            // 
            // barListItem1
            // 
            this.barListItem1.Caption = "barListItem1";
            this.barListItem1.Id = 6;
            this.barListItem1.Name = "barListItem1";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Caption = "barButtonGroup1";
            this.barButtonGroup1.Id = 7;
            this.barButtonGroup1.Name = "barButtonGroup1";
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "barSubItem2";
            this.barSubItem2.Id = 8;
            this.barSubItem2.Name = "barSubItem2";
            // 
            // barMdiChildrenListItem1
            // 
            this.barMdiChildrenListItem1.Caption = "barMdiChildrenListItem1";
            this.barMdiChildrenListItem1.Id = 9;
            this.barMdiChildrenListItem1.Name = "barMdiChildrenListItem1";
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Caption = "barStaticItem2";
            this.barStaticItem2.Id = 10;
            this.barStaticItem2.Name = "barStaticItem2";
            // 
            // btnNV
            // 
            this.btnNV.Caption = "Nhan Vien";
            this.btnNV.Id = 11;
            this.btnNV.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnNV.ImageOptions.Image")));
            this.btnNV.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnNV.ImageOptions.LargeImage")));
            this.btnNV.Name = "btnNV";
            this.btnNV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNV_ItemClick);
            // 
            // btnPhgBan
            // 
            this.btnPhgBan.Caption = "Phong Ban";
            this.btnPhgBan.Id = 12;
            this.btnPhgBan.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnPhgBan.ImageOptions.Image")));
            this.btnPhgBan.Name = "btnPhgBan";
            this.btnPhgBan.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnPhgBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhgBan_ItemClick);
            // 
            // btnPhanQuyen
            // 
            this.btnPhanQuyen.Caption = "Phan Quyen";
            this.btnPhanQuyen.Id = 13;
            this.btnPhanQuyen.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnPhanQuyen.ImageOptions.Image")));
            this.btnPhanQuyen.Name = "btnPhanQuyen";
            this.btnPhanQuyen.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnPhanQuyen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhanQuyen_ItemClick);
            // 
            // btnDSTour
            // 
            this.btnDSTour.Caption = "barButtonItem2";
            this.btnDSTour.Id = 14;
            this.btnDSTour.Name = "btnDSTour";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "barButtonItem2";
            this.barButtonItem2.Id = 15;
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "barButtonItem3";
            this.barButtonItem3.Id = 16;
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // ribbonPageCategory1
            // 
            this.ribbonPageCategory1.Name = "ribbonPageCategory1";
            this.ribbonPageCategory1.Text = "ribbonPageCategory1";
            // 
            // frmMain_QLHT
            // 
            this.frmMain_QLHT.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.frmMain_HThong,
            this.frmMain_PQ,
            this.frmPQ});
            this.frmMain_QLHT.Image = ((System.Drawing.Image)(resources.GetObject("frmMain_QLHT.Image")));
            this.frmMain_QLHT.Name = "frmMain_QLHT";
            this.frmMain_QLHT.Text = "Quản lí hệ thống";
            // 
            // frmMain_HThong
            // 
            this.frmMain_HThong.ImageUri.Uri = "BringForward";
            this.frmMain_HThong.ItemLinks.Add(this.btnNV);
            this.frmMain_HThong.ItemLinks.Add(this.btnPhgBan);
            this.frmMain_HThong.Name = "frmMain_HThong";
            this.frmMain_HThong.Text = "He thong";
            // 
            // frmMain_PQ
            // 
            this.frmMain_PQ.Glyph = ((System.Drawing.Image)(resources.GetObject("frmMain_PQ.Glyph")));
            this.frmMain_PQ.ItemLinks.Add(this.btnPhanQuyen);
            this.frmMain_PQ.Name = "frmMain_PQ";
            this.frmMain_PQ.Text = "Phan Quyen";
            // 
            // frmPQ
            // 
            this.frmPQ.Name = "frmPQ";
            this.frmPQ.Text = "Phân công";
            // 
            // FrmMain_QLTour
            // 
            this.FrmMain_QLTour.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.frmQLTour,
            this.frmQLCTTour,
            this.frmQLTKTour_Ycau,
            this.frmQLTKTour_CoSan,
            this.frmQLKS,
            this.frmQLHDV});
            this.FrmMain_QLTour.Image = ((System.Drawing.Image)(resources.GetObject("FrmMain_QLTour.Image")));
            this.FrmMain_QLTour.Name = "FrmMain_QLTour";
            this.FrmMain_QLTour.Text = "Quản lí tour du lịch";
            // 
            // frmQLTour
            // 
            this.frmQLTour.ItemLinks.Add(this.btnDSTour);
            this.frmQLTour.ItemLinks.Add(this.barButtonItem2);
            this.frmQLTour.ItemLinks.Add(this.barButtonItem3);
            this.frmQLTour.Name = "frmQLTour";
            this.frmQLTour.Text = "Danh sách tour";
            // 
            // frmQLCTTour
            // 
            this.frmQLCTTour.Name = "frmQLCTTour";
            this.frmQLCTTour.Text = "Danh sách chi tiết tour";
            // 
            // frmQLTKTour_Ycau
            // 
            this.frmQLTKTour_Ycau.Name = "frmQLTKTour_Ycau";
            this.frmQLTKTour_Ycau.Text = "Thiết kế tour theo yêu cầu";
            // 
            // frmQLTKTour_CoSan
            // 
            this.frmQLTKTour_CoSan.Name = "frmQLTKTour_CoSan";
            this.frmQLTKTour_CoSan.Text = "Thiết kế theo tour có sẵn";
            // 
            // frmQLKS
            // 
            this.frmQLKS.Name = "frmQLKS";
            this.frmQLKS.Text = "Danh sách đối tác";
            // 
            // frmQLHDV
            // 
            this.frmQLHDV.Name = "frmQLHDV";
            this.frmQLHDV.Text = "Danh sách hướng dẫn viên";
            // 
            // frmMain_QLKDTour
            // 
            this.frmMain_QLKDTour.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.frmQLTour_KhachLe,
            this.frmQLKH,
            this.ribbonPageGroup1,
            this.frmQLHD,
            this.ribbonPageGroup2});
            this.frmMain_QLKDTour.Image = ((System.Drawing.Image)(resources.GetObject("frmMain_QLKDTour.Image")));
            this.frmMain_QLKDTour.Name = "frmMain_QLKDTour";
            this.frmMain_QLKDTour.Text = "Quản lí kinh doanh tour";
            // 
            // frmQLTour_KhachLe
            // 
            this.frmQLTour_KhachLe.Name = "frmQLTour_KhachLe";
            this.frmQLTour_KhachLe.Text = "Danh sách tour";
            // 
            // frmQLKH
            // 
            this.frmQLKH.Name = "frmQLKH";
            this.frmQLKH.Text = "Quản lí khách hàng";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // frmQLHD
            // 
            this.frmQLHD.Name = "frmQLHD";
            this.frmQLHD.Text = "Danh sách hợp đồng";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "ribbonPageGroup2";
            // 
            // frmMain_DoanhThu
            // 
            this.frmMain_DoanhThu.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.frmQLDT_TheoThang,
            this.frmQLDT_TheoNam});
            this.frmMain_DoanhThu.Image = ((System.Drawing.Image)(resources.GetObject("frmMain_DoanhThu.Image")));
            this.frmMain_DoanhThu.Name = "frmMain_DoanhThu";
            this.frmMain_DoanhThu.Text = "Thống kê doanh thu";
            // 
            // frmQLDT_TheoThang
            // 
            this.frmQLDT_TheoThang.Name = "frmQLDT_TheoThang";
            this.frmQLDT_TheoThang.Text = "Doanh thu theo tháng";
            // 
            // frmQLDT_TheoNam
            // 
            this.frmQLDT_TheoNam.Name = "frmQLDT_TheoNam";
            this.frmQLDT_TheoNam.Text = "Doanh thu theo năm";
            // 
            // frmMain_Report
            // 
            this.frmMain_Report.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3});
            this.frmMain_Report.Image = ((System.Drawing.Image)(resources.GetObject("frmMain_Report.Image")));
            this.frmMain_Report.Name = "frmMain_Report";
            this.frmMain_Report.Text = "Report";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "ribbonPageGroup3";
            // 
            // Form1
            // 
            this.AllowFormGlass = DevExpress.Utils.DefaultBoolean.False;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 491);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "Form1";
            this.Ribbon = this.ribbonControl1;
            this.Text = "frmMain";
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage frmMain_QLHT;
        private DevExpress.XtraBars.Ribbon.RibbonPage FrmMain_QLTour;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLTour;
        private DevExpress.XtraBars.Ribbon.RibbonPage frmMain_QLKDTour;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLTour_KhachLe;
        private DevExpress.XtraBars.Ribbon.RibbonPage frmMain_DoanhThu;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLDT_TheoThang;
        private DevExpress.XtraBars.BarHeaderItem barHeaderItem1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.RibbonGalleryBarItem ribbonGalleryBarItem1;
        private DevExpress.XtraBars.BarListItem barListItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmMain_PQ;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmPQ;
        public DevExpress.XtraBars.Ribbon.RibbonPageGroup frmMain_HThong;
        private DevExpress.XtraBars.Ribbon.RibbonPageCategory ribbonPageCategory1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLCTTour;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLTKTour_CoSan;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraBars.BarMdiChildrenListItem barMdiChildrenListItem1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLTKTour_Ycau;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLKS;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLHDV;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLKH;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLHD;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup frmQLDT_TheoNam;
        private DevExpress.XtraBars.Ribbon.RibbonPage frmMain_Report;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.BarButtonItem btnNV;
        private DevExpress.XtraBars.BarButtonItem btnPhgBan;
        private DevExpress.XtraBars.BarButtonItem btnPhanQuyen;
        private DevExpress.XtraBars.BarButtonItem btnDSTour;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
    }
}

