﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FrmMain
{
    public partial class Form1 : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ribbonControl1_Click(object sender, EventArgs e)
        {

        }

        private void btnNV_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmQLNV form = new frmQLNV();
          //  form.MdiParent = this;
            form.Show();
        }

        private void btnPhanQuyen_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmDMTour form = new frmDMTour();
            form.Show();
            
            
        }

        private void btnPhgBan_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmChucNangTour form = new frmChucNangTour();
            form.Show();
        }
    }
}
