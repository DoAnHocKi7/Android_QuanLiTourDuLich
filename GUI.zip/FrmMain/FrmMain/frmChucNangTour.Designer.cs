﻿namespace FrmMain
{
    partial class frmChucNangTour
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label tenTourLabel;
            System.Windows.Forms.Label ngayKhoiHanhLabel;
            System.Windows.Forms.Label ngayKetThucLabel;
            System.Windows.Forms.Label moTaLabel;
            System.Windows.Forms.Label maLoaiTourLabel;
            System.Windows.Forms.Label maHanhTrinhLabel;
            System.Windows.Forms.Label maHDVLabel;
            System.Windows.Forms.Label anhDaiDienLabel;
            System.Windows.Forms.Label giaTreEmLabel;
            System.Windows.Forms.Label giaNguoiLonLabel;
            System.Windows.Forms.Label soLuongDuKhachLabel;
            System.Windows.Forms.Label maTourLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChucNangTour));
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.maTourTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.tOURBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new FrmMain.DataSet1();
            this.soLuongDuKhachTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.giaNguoiLonTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.giaTreEmTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.btnSaveTour = new DevExpress.XtraEditors.SimpleButton();
            this.btnSuaTour = new DevExpress.XtraEditors.SimpleButton();
            this.btnXoaTour = new DevExpress.XtraEditors.SimpleButton();
            this.btnThemTour = new DevExpress.XtraEditors.SimpleButton();
            this.btnRefesh = new DevExpress.XtraEditors.SimpleButton();
            this.anhDaiDienTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.tenTourTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ngayKhoiHanhDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.ngayKetThucDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.moTaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.maLoaiTourSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.maHanhTrinhSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.maHDVSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.tOURTableAdapter = new FrmMain.DataSet1TableAdapters.TOURTableAdapter();
            this.tableAdapterManager = new FrmMain.DataSet1TableAdapters.TableAdapterManager();
            this.tOURBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tOURBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.tOURGridControl = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            tenTourLabel = new System.Windows.Forms.Label();
            ngayKhoiHanhLabel = new System.Windows.Forms.Label();
            ngayKetThucLabel = new System.Windows.Forms.Label();
            moTaLabel = new System.Windows.Forms.Label();
            maLoaiTourLabel = new System.Windows.Forms.Label();
            maHanhTrinhLabel = new System.Windows.Forms.Label();
            maHDVLabel = new System.Windows.Forms.Label();
            anhDaiDienLabel = new System.Windows.Forms.Label();
            giaTreEmLabel = new System.Windows.Forms.Label();
            giaNguoiLonLabel = new System.Windows.Forms.Label();
            soLuongDuKhachLabel = new System.Windows.Forms.Label();
            maTourLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maTourTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soLuongDuKhachTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaNguoiLonTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaTreEmTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhDaiDienTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenTourTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.moTaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maLoaiTourSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHanhTrinhSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHDVSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingNavigator)).BeginInit();
            this.tOURBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tOURGridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tenTourLabel
            // 
            tenTourLabel.AutoSize = true;
            tenTourLabel.Location = new System.Drawing.Point(51, 65);
            tenTourLabel.Name = "tenTourLabel";
            tenTourLabel.Size = new System.Drawing.Size(54, 13);
            tenTourLabel.TabIndex = 2;
            tenTourLabel.Text = "Ten Tour:";
            // 
            // ngayKhoiHanhLabel
            // 
            ngayKhoiHanhLabel.AutoSize = true;
            ngayKhoiHanhLabel.Location = new System.Drawing.Point(51, 91);
            ngayKhoiHanhLabel.Name = "ngayKhoiHanhLabel";
            ngayKhoiHanhLabel.Size = new System.Drawing.Size(87, 13);
            ngayKhoiHanhLabel.TabIndex = 4;
            ngayKhoiHanhLabel.Text = "Ngay Khoi Hanh:";
            // 
            // ngayKetThucLabel
            // 
            ngayKetThucLabel.AutoSize = true;
            ngayKetThucLabel.Location = new System.Drawing.Point(51, 117);
            ngayKetThucLabel.Name = "ngayKetThucLabel";
            ngayKetThucLabel.Size = new System.Drawing.Size(81, 13);
            ngayKetThucLabel.TabIndex = 6;
            ngayKetThucLabel.Text = "Ngay Ket Thuc:";
            // 
            // moTaLabel
            // 
            moTaLabel.AutoSize = true;
            moTaLabel.Location = new System.Drawing.Point(313, 39);
            moTaLabel.Name = "moTaLabel";
            moTaLabel.Size = new System.Drawing.Size(40, 13);
            moTaLabel.TabIndex = 12;
            moTaLabel.Text = "Mo Ta:";
            // 
            // maLoaiTourLabel
            // 
            maLoaiTourLabel.AutoSize = true;
            maLoaiTourLabel.Location = new System.Drawing.Point(313, 65);
            maLoaiTourLabel.Name = "maLoaiTourLabel";
            maLoaiTourLabel.Size = new System.Drawing.Size(72, 13);
            maLoaiTourLabel.TabIndex = 14;
            maLoaiTourLabel.Text = "Ma Loai Tour:";
            // 
            // maHanhTrinhLabel
            // 
            maHanhTrinhLabel.AutoSize = true;
            maHanhTrinhLabel.Location = new System.Drawing.Point(313, 91);
            maHanhTrinhLabel.Name = "maHanhTrinhLabel";
            maHanhTrinhLabel.Size = new System.Drawing.Size(80, 13);
            maHanhTrinhLabel.TabIndex = 16;
            maHanhTrinhLabel.Text = "Ma Hanh Trinh:";
            // 
            // maHDVLabel
            // 
            maHDVLabel.AutoSize = true;
            maHDVLabel.Location = new System.Drawing.Point(313, 117);
            maHDVLabel.Name = "maHDVLabel";
            maHDVLabel.Size = new System.Drawing.Size(48, 13);
            maHDVLabel.TabIndex = 18;
            maHDVLabel.Text = "Ma HDV:";
            // 
            // anhDaiDienLabel
            // 
            anhDaiDienLabel.AutoSize = true;
            anhDaiDienLabel.Location = new System.Drawing.Point(547, 128);
            anhDaiDienLabel.Name = "anhDaiDienLabel";
            anhDaiDienLabel.Size = new System.Drawing.Size(72, 13);
            anhDaiDienLabel.TabIndex = 23;
            anhDaiDienLabel.Text = "Anh Dai Dien:";
            // 
            // giaTreEmLabel
            // 
            giaTreEmLabel.AutoSize = true;
            giaTreEmLabel.Location = new System.Drawing.Point(547, 39);
            giaTreEmLabel.Name = "giaTreEmLabel";
            giaTreEmLabel.Size = new System.Drawing.Size(62, 13);
            giaTreEmLabel.TabIndex = 30;
            giaTreEmLabel.Text = "Gia Tre Em:";
            // 
            // giaNguoiLonLabel
            // 
            giaNguoiLonLabel.AutoSize = true;
            giaNguoiLonLabel.Location = new System.Drawing.Point(547, 69);
            giaNguoiLonLabel.Name = "giaNguoiLonLabel";
            giaNguoiLonLabel.Size = new System.Drawing.Size(76, 13);
            giaNguoiLonLabel.TabIndex = 31;
            giaNguoiLonLabel.Text = "Gia Nguoi Lon:";
            // 
            // soLuongDuKhachLabel
            // 
            soLuongDuKhachLabel.AutoSize = true;
            soLuongDuKhachLabel.Location = new System.Drawing.Point(547, 98);
            soLuongDuKhachLabel.Name = "soLuongDuKhachLabel";
            soLuongDuKhachLabel.Size = new System.Drawing.Size(103, 13);
            soLuongDuKhachLabel.TabIndex = 32;
            soLuongDuKhachLabel.Text = "So Luong Du Khach:";
            // 
            // maTourLabel
            // 
            maTourLabel.AutoSize = true;
            maTourLabel.Location = new System.Drawing.Point(51, 39);
            maTourLabel.Name = "maTourLabel";
            maTourLabel.Size = new System.Drawing.Size(50, 13);
            maTourLabel.TabIndex = 33;
            maTourLabel.Text = "Ma Tour:";
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(maTourLabel);
            this.groupControl1.Controls.Add(this.maTourTextEdit);
            this.groupControl1.Controls.Add(soLuongDuKhachLabel);
            this.groupControl1.Controls.Add(this.soLuongDuKhachTextEdit);
            this.groupControl1.Controls.Add(giaNguoiLonLabel);
            this.groupControl1.Controls.Add(this.giaNguoiLonTextEdit);
            this.groupControl1.Controls.Add(giaTreEmLabel);
            this.groupControl1.Controls.Add(this.giaTreEmTextEdit);
            this.groupControl1.Controls.Add(this.btnCancel);
            this.groupControl1.Controls.Add(this.btnSaveTour);
            this.groupControl1.Controls.Add(this.btnSuaTour);
            this.groupControl1.Controls.Add(this.btnXoaTour);
            this.groupControl1.Controls.Add(this.btnThemTour);
            this.groupControl1.Controls.Add(this.btnRefesh);
            this.groupControl1.Controls.Add(anhDaiDienLabel);
            this.groupControl1.Controls.Add(this.anhDaiDienTextEdit);
            this.groupControl1.Controls.Add(tenTourLabel);
            this.groupControl1.Controls.Add(this.tenTourTextEdit);
            this.groupControl1.Controls.Add(ngayKhoiHanhLabel);
            this.groupControl1.Controls.Add(this.ngayKhoiHanhDateEdit);
            this.groupControl1.Controls.Add(ngayKetThucLabel);
            this.groupControl1.Controls.Add(this.ngayKetThucDateEdit);
            this.groupControl1.Controls.Add(moTaLabel);
            this.groupControl1.Controls.Add(this.moTaTextEdit);
            this.groupControl1.Controls.Add(maLoaiTourLabel);
            this.groupControl1.Controls.Add(this.maLoaiTourSpinEdit);
            this.groupControl1.Controls.Add(maHanhTrinhLabel);
            this.groupControl1.Controls.Add(this.maHanhTrinhSpinEdit);
            this.groupControl1.Controls.Add(maHDVLabel);
            this.groupControl1.Controls.Add(this.maHDVSpinEdit);
            this.groupControl1.Location = new System.Drawing.Point(12, 104);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(886, 209);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "groupControl1";
            // 
            // maTourTextEdit
            // 
            this.maTourTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaTour", true));
            this.maTourTextEdit.Enabled = false;
            this.maTourTextEdit.Location = new System.Drawing.Point(160, 36);
            this.maTourTextEdit.Name = "maTourTextEdit";
            this.maTourTextEdit.Size = new System.Drawing.Size(100, 20);
            this.maTourTextEdit.TabIndex = 34;
            // 
            // tOURBindingSource
            // 
            this.tOURBindingSource.DataMember = "TOUR";
            this.tOURBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // soLuongDuKhachTextEdit
            // 
            this.soLuongDuKhachTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "SoLuongDuKhach", true));
            this.soLuongDuKhachTextEdit.Enabled = false;
            this.soLuongDuKhachTextEdit.Location = new System.Drawing.Point(656, 95);
            this.soLuongDuKhachTextEdit.Name = "soLuongDuKhachTextEdit";
            this.soLuongDuKhachTextEdit.Size = new System.Drawing.Size(100, 20);
            this.soLuongDuKhachTextEdit.TabIndex = 33;
            // 
            // giaNguoiLonTextEdit
            // 
            this.giaNguoiLonTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "GiaNguoiLon", true));
            this.giaNguoiLonTextEdit.Enabled = false;
            this.giaNguoiLonTextEdit.Location = new System.Drawing.Point(656, 66);
            this.giaNguoiLonTextEdit.Name = "giaNguoiLonTextEdit";
            this.giaNguoiLonTextEdit.Size = new System.Drawing.Size(100, 20);
            this.giaNguoiLonTextEdit.TabIndex = 32;
            // 
            // giaTreEmTextEdit
            // 
            this.giaTreEmTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "GiaTreEm", true));
            this.giaTreEmTextEdit.Enabled = false;
            this.giaTreEmTextEdit.Location = new System.Drawing.Point(656, 36);
            this.giaTreEmTextEdit.Name = "giaTreEmTextEdit";
            this.giaTreEmTextEdit.Size = new System.Drawing.Size(100, 20);
            this.giaTreEmTextEdit.TabIndex = 31;
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = global::FrmMain.Properties.Resources.greeen;
            this.btnCancel.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.btnCancel.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.ImageOptions.Image")));
            this.btnCancel.Location = new System.Drawing.Point(465, 151);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(92, 32);
            this.btnCancel.TabIndex = 30;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSaveTour
            // 
            this.btnSaveTour.BackgroundImage = global::FrmMain.Properties.Resources.Pink1;
            this.btnSaveTour.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.btnSaveTour.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveTour.ImageOptions.Image")));
            this.btnSaveTour.Location = new System.Drawing.Point(367, 151);
            this.btnSaveTour.Name = "btnSaveTour";
            this.btnSaveTour.Size = new System.Drawing.Size(92, 32);
            this.btnSaveTour.TabIndex = 29;
            this.btnSaveTour.Text = "Save";
            this.btnSaveTour.Click += new System.EventHandler(this.btnSaveTour_Click);
            // 
            // btnSuaTour
            // 
            this.btnSuaTour.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSuaTour.BackgroundImage")));
            this.btnSuaTour.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.btnSuaTour.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSuaTour.ImageOptions.Image")));
            this.btnSuaTour.Location = new System.Drawing.Point(171, 151);
            this.btnSuaTour.Name = "btnSuaTour";
            this.btnSuaTour.Size = new System.Drawing.Size(92, 32);
            this.btnSuaTour.TabIndex = 28;
            this.btnSuaTour.Text = "Edit";
            this.btnSuaTour.Click += new System.EventHandler(this.btnSuaTour_Click);
            // 
            // btnXoaTour
            // 
            this.btnXoaTour.BackgroundImage = global::FrmMain.Properties.Resources.greeen;
            this.btnXoaTour.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.btnXoaTour.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnXoaTour.ImageOptions.Image")));
            this.btnXoaTour.Location = new System.Drawing.Point(269, 151);
            this.btnXoaTour.Name = "btnXoaTour";
            this.btnXoaTour.Size = new System.Drawing.Size(92, 32);
            this.btnXoaTour.TabIndex = 27;
            this.btnXoaTour.Text = "Delete";
            this.btnXoaTour.Click += new System.EventHandler(this.btnXoaTour_Click);
            // 
            // btnThemTour
            // 
            this.btnThemTour.BackgroundImage = global::FrmMain.Properties.Resources.images__1_;
            this.btnThemTour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThemTour.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.btnThemTour.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnThemTour.ImageOptions.Image")));
            this.btnThemTour.Location = new System.Drawing.Point(73, 151);
            this.btnThemTour.Name = "btnThemTour";
            this.btnThemTour.Size = new System.Drawing.Size(92, 32);
            this.btnThemTour.TabIndex = 26;
            this.btnThemTour.Text = "Insert";
            this.btnThemTour.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnRefesh
            // 
            this.btnRefesh.BackgroundImage = global::FrmMain.Properties.Resources.yellow;
            this.btnRefesh.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.btnRefesh.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnRefesh.ImageOptions.Image")));
            this.btnRefesh.Location = new System.Drawing.Point(574, 151);
            this.btnRefesh.Name = "btnRefesh";
            this.btnRefesh.Size = new System.Drawing.Size(92, 32);
            this.btnRefesh.TabIndex = 25;
            this.btnRefesh.Text = "Refesh";
            // 
            // anhDaiDienTextEdit
            // 
            this.anhDaiDienTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "AnhDaiDien", true));
            this.anhDaiDienTextEdit.Enabled = false;
            this.anhDaiDienTextEdit.Location = new System.Drawing.Point(656, 125);
            this.anhDaiDienTextEdit.Name = "anhDaiDienTextEdit";
            this.anhDaiDienTextEdit.Size = new System.Drawing.Size(100, 20);
            this.anhDaiDienTextEdit.TabIndex = 24;
            // 
            // tenTourTextEdit
            // 
            this.tenTourTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "TenTour", true));
            this.tenTourTextEdit.Enabled = false;
            this.tenTourTextEdit.Location = new System.Drawing.Point(160, 62);
            this.tenTourTextEdit.Name = "tenTourTextEdit";
            this.tenTourTextEdit.Size = new System.Drawing.Size(100, 20);
            this.tenTourTextEdit.TabIndex = 3;
            // 
            // ngayKhoiHanhDateEdit
            // 
            this.ngayKhoiHanhDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "NgayKhoiHanh", true));
            this.ngayKhoiHanhDateEdit.EditValue = null;
            this.ngayKhoiHanhDateEdit.Enabled = false;
            this.ngayKhoiHanhDateEdit.Location = new System.Drawing.Point(160, 88);
            this.ngayKhoiHanhDateEdit.Name = "ngayKhoiHanhDateEdit";
            this.ngayKhoiHanhDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKhoiHanhDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKhoiHanhDateEdit.Size = new System.Drawing.Size(100, 20);
            this.ngayKhoiHanhDateEdit.TabIndex = 5;
            // 
            // ngayKetThucDateEdit
            // 
            this.ngayKetThucDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "NgayKetThuc", true));
            this.ngayKetThucDateEdit.EditValue = null;
            this.ngayKetThucDateEdit.Enabled = false;
            this.ngayKetThucDateEdit.Location = new System.Drawing.Point(160, 114);
            this.ngayKetThucDateEdit.Name = "ngayKetThucDateEdit";
            this.ngayKetThucDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKetThucDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKetThucDateEdit.Size = new System.Drawing.Size(100, 20);
            this.ngayKetThucDateEdit.TabIndex = 7;
            // 
            // moTaTextEdit
            // 
            this.moTaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MoTa", true));
            this.moTaTextEdit.Enabled = false;
            this.moTaTextEdit.Location = new System.Drawing.Point(422, 36);
            this.moTaTextEdit.Name = "moTaTextEdit";
            this.moTaTextEdit.Size = new System.Drawing.Size(100, 20);
            this.moTaTextEdit.TabIndex = 13;
            // 
            // maLoaiTourSpinEdit
            // 
            this.maLoaiTourSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaLoaiTour", true));
            this.maLoaiTourSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maLoaiTourSpinEdit.Enabled = false;
            this.maLoaiTourSpinEdit.Location = new System.Drawing.Point(422, 62);
            this.maLoaiTourSpinEdit.Name = "maLoaiTourSpinEdit";
            this.maLoaiTourSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maLoaiTourSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maLoaiTourSpinEdit.TabIndex = 15;
            // 
            // maHanhTrinhSpinEdit
            // 
            this.maHanhTrinhSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaHanhTrinh", true));
            this.maHanhTrinhSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maHanhTrinhSpinEdit.Enabled = false;
            this.maHanhTrinhSpinEdit.Location = new System.Drawing.Point(422, 88);
            this.maHanhTrinhSpinEdit.Name = "maHanhTrinhSpinEdit";
            this.maHanhTrinhSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maHanhTrinhSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maHanhTrinhSpinEdit.TabIndex = 17;
            // 
            // maHDVSpinEdit
            // 
            this.maHDVSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaHDV", true));
            this.maHDVSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maHDVSpinEdit.Enabled = false;
            this.maHDVSpinEdit.Location = new System.Drawing.Point(422, 114);
            this.maHDVSpinEdit.Name = "maHDVSpinEdit";
            this.maHDVSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maHDVSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maHDVSpinEdit.TabIndex = 19;
            // 
            // tOURTableAdapter
            // 
            this.tOURTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TOURTableAdapter = this.tOURTableAdapter;
            this.tableAdapterManager.UpdateOrder = FrmMain.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tOURBindingNavigator
            // 
            this.tOURBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tOURBindingNavigator.BindingSource = this.tOURBindingSource;
            this.tOURBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tOURBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tOURBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tOURBindingNavigatorSaveItem});
            this.tOURBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tOURBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tOURBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tOURBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tOURBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tOURBindingNavigator.Name = "tOURBindingNavigator";
            this.tOURBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tOURBindingNavigator.Size = new System.Drawing.Size(1038, 25);
            this.tOURBindingNavigator.TabIndex = 1;
            this.tOURBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tOURBindingNavigatorSaveItem
            // 
            this.tOURBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tOURBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tOURBindingNavigatorSaveItem.Image")));
            this.tOURBindingNavigatorSaveItem.Name = "tOURBindingNavigatorSaveItem";
            this.tOURBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tOURBindingNavigatorSaveItem.Text = "Save Data";
            this.tOURBindingNavigatorSaveItem.Click += new System.EventHandler(this.tOURBindingNavigatorSaveItem_Click);
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.tOURGridControl);
            this.groupControl2.Location = new System.Drawing.Point(0, 343);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(1013, 290);
            this.groupControl2.TabIndex = 2;
            this.groupControl2.Text = "groupControl2";
            // 
            // tOURGridControl
            // 
            this.tOURGridControl.DataSource = this.tOURBindingSource;
            this.tOURGridControl.Location = new System.Drawing.Point(5, 23);
            this.tOURGridControl.MainView = this.gridView1;
            this.tOURGridControl.Name = "tOURGridControl";
            this.tOURGridControl.Size = new System.Drawing.Size(994, 256);
            this.tOURGridControl.TabIndex = 0;
            this.tOURGridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.tOURGridControl;
            this.gridView1.Name = "gridView1";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Location = new System.Drawing.Point(408, 28);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(164, 29);
            this.labelControl1.TabIndex = 3;
            this.labelControl1.Text = "Chức năng tour";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frmChucNangTour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1038, 645);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.tOURBindingNavigator);
            this.Controls.Add(this.groupControl1);
            this.Name = "frmChucNangTour";
            this.Text = "frmChucNangTour";
            this.Load += new System.EventHandler(this.frmChucNangTour_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maTourTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soLuongDuKhachTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaNguoiLonTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaTreEmTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhDaiDienTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenTourTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.moTaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maLoaiTourSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHanhTrinhSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHDVSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingNavigator)).EndInit();
            this.tOURBindingNavigator.ResumeLayout(false);
            this.tOURBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tOURGridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource tOURBindingSource;
        private DataSet1TableAdapters.TOURTableAdapter tOURTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tOURBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tOURBindingNavigatorSaveItem;
        private DevExpress.XtraEditors.TextEdit anhDaiDienTextEdit;
        private DevExpress.XtraEditors.TextEdit tenTourTextEdit;
        private DevExpress.XtraEditors.DateEdit ngayKhoiHanhDateEdit;
        private DevExpress.XtraEditors.DateEdit ngayKetThucDateEdit;
        private DevExpress.XtraEditors.TextEdit moTaTextEdit;
        private DevExpress.XtraEditors.SpinEdit maLoaiTourSpinEdit;
        private DevExpress.XtraEditors.SpinEdit maHanhTrinhSpinEdit;
        private DevExpress.XtraEditors.SpinEdit maHDVSpinEdit;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraGrid.GridControl tOURGridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.SimpleButton btnSaveTour;
        private DevExpress.XtraEditors.SimpleButton btnSuaTour;
        private DevExpress.XtraEditors.SimpleButton btnXoaTour;
        private DevExpress.XtraEditors.SimpleButton btnThemTour;
        private DevExpress.XtraEditors.SimpleButton btnRefesh;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit soLuongDuKhachTextEdit;
        private DevExpress.XtraEditors.TextEdit giaNguoiLonTextEdit;
        private DevExpress.XtraEditors.TextEdit giaTreEmTextEdit;
        private DevExpress.XtraEditors.TextEdit maTourTextEdit;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}