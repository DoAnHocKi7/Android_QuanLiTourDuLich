﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace FrmMain
{
    public partial class frmChucNangTour : DevExpress.XtraEditors.XtraForm
    {
        private DataSet1 QlTourDuLichDataSet;
        public frmChucNangTour()
        {
            InitializeComponent();
        }

        private void tOURBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tOURBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }

        private void frmChucNangTour_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.TOUR' table. You can move, or remove it, as needed.
            this.tOURTableAdapter.Fill(this.dataSet1.TOUR);
            XuLyButton(true);


        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            this.tOURBindingSource.AddNew();
            this.tableAdapterManager.UpdateAll(this.dataSet1);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            XuLyButton(true);
            XuLyTextBox(true);
            btnSaveTour.Enabled = btnCancel.Enabled = true;
            btnXoaTour.Enabled = btnSuaTour.Enabled = false;
            this.tOURBindingSource.AddNew();
            this.tableAdapterManager.UpdateAll(this.dataSet1);
           
            
            
        }
        public void XuLyTextBox(bool b)
        {
             tenTourTextEdit.Enabled = ngayKhoiHanhDateEdit.Enabled = ngayKetThucDateEdit.Enabled = b;
            moTaTextEdit.Enabled = maLoaiTourSpinEdit.Enabled = maHanhTrinhSpinEdit.Enabled = maHDVSpinEdit.Enabled = b;
            giaNguoiLonTextEdit.Enabled = giaTreEmTextEdit.Enabled = soLuongDuKhachTextEdit.Enabled = anhDaiDienTextEdit.Enabled = b;
            maTourTextEdit.Enabled = !b;
        }
        public void XuLyButton(bool b)
        {
            
            btnThemTour.Enabled = btnXoaTour.Enabled = btnSuaTour.Enabled = b;
            btnSaveTour.Enabled = btnCancel.Enabled = !b;

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.tOURBindingSource.CancelEdit();
            XuLyButton(true);
        }

        private void btnXoaTour_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Bạn có chắc chắn chưa?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question)) ;
            {
                this.tOURBindingSource.RemoveCurrent();
                this.tableAdapterManager.UpdateAll(this.dataSet1);
            }

        }

        private void btnSaveTour_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tOURBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);
            XuLyButton(true);
            
        }

        private void btnSuaTour_Click(object sender, EventArgs e)
        {

            XuLyButton(false);
            tenTourTextEdit.Focus();
            XuLyTextBox(true);

           


        }

    }
}