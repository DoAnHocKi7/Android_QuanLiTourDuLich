﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using ClassLibrary1;

namespace FrmMain
{
    public partial class frmDMTour : DevExpress.XtraEditors.XtraForm
    {
        public frmDMTour()
        {
            InitializeComponent();
        }

        private void tOURBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tOURBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }

        private void frmDMTour_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.TOUR' table. You can move, or remove it, as needed.
            this.tOURTableAdapter.Fill(this.dataSet1.TOUR);
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-1FR6IG6\\SQLEXPRESS;Initial Catalog=QlTourDuLich;Integrated Security=True");
            SqlDataAdapter da=new SqlDataAdapter("SELECT * From TOUR",conn);
            DataTable table=new DataTable();
            da.Fill(table);
            int k = 0, j = 0;
            for (int i = 0; i < table.Rows.Count; i++)
            {
                UserControl1 usertour = new UserControl1();
              //  usertour.Width = 153;
             //   usertour.Height = 135;
                usertour.Top = 50 + j * 177;
                usertour.Left = 50 + k * 127;
               
                usertour.label1.Text = table.Rows[i][0].ToString();
                usertour.label2.Text = table.Rows[i][2].ToString();
                usertour.label3.Text = table.Rows[i][3].ToString();
                usertour.label4.Text = table.Rows[i][11].ToString();
              //  usertour.Left = left;
                this.Controls.Add(usertour);
                k++;
                if (k == 5)                                     //Tạo hàng 4 hình
                {
                    k = 0; j++;
                }
                
            }



        }
    }
}