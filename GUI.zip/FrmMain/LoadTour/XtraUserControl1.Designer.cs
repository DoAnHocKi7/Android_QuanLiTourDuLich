﻿namespace LoadTour
{
    partial class XtraUserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(XtraUserControl1));
            System.Windows.Forms.Label maTourLabel;
            System.Windows.Forms.Label tenTourLabel;
            System.Windows.Forms.Label ngayKhoiHanhLabel;
            System.Windows.Forms.Label ngayKetThucLabel;
            System.Windows.Forms.Label giaTreEmLabel;
            System.Windows.Forms.Label giaNguoiLonLabel;
            System.Windows.Forms.Label moTaLabel;
            System.Windows.Forms.Label maLoaiTourLabel;
            System.Windows.Forms.Label maHanhTrinhLabel;
            System.Windows.Forms.Label maHDVLabel;
            System.Windows.Forms.Label anhDaiDienLabel;
            System.Windows.Forms.Label soLuongDuKhachLabel;
            this.qlTourDuLichDataSet = new LoadTour.QlTourDuLichDataSet();
            this.tOURBindingSource = new System.Windows.Forms.BindingSource();
            this.tOURTableAdapter = new LoadTour.QlTourDuLichDataSetTableAdapters.TOURTableAdapter();
            this.tableAdapterManager = new LoadTour.QlTourDuLichDataSetTableAdapters.TableAdapterManager();
            this.tOURBindingNavigator = new System.Windows.Forms.BindingNavigator();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tOURBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.maTourSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.tenTourTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ngayKhoiHanhDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.ngayKetThucDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.giaTreEmSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.giaNguoiLonSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.moTaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.maLoaiTourSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.maHanhTrinhSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.maHDVSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.anhDaiDienTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.soLuongDuKhachSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            maTourLabel = new System.Windows.Forms.Label();
            tenTourLabel = new System.Windows.Forms.Label();
            ngayKhoiHanhLabel = new System.Windows.Forms.Label();
            ngayKetThucLabel = new System.Windows.Forms.Label();
            giaTreEmLabel = new System.Windows.Forms.Label();
            giaNguoiLonLabel = new System.Windows.Forms.Label();
            moTaLabel = new System.Windows.Forms.Label();
            maLoaiTourLabel = new System.Windows.Forms.Label();
            maHanhTrinhLabel = new System.Windows.Forms.Label();
            maHDVLabel = new System.Windows.Forms.Label();
            anhDaiDienLabel = new System.Windows.Forms.Label();
            soLuongDuKhachLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.qlTourDuLichDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingNavigator)).BeginInit();
            this.tOURBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maTourSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenTourTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaTreEmSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaNguoiLonSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.moTaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maLoaiTourSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHanhTrinhSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHDVSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhDaiDienTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soLuongDuKhachSpinEdit.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // qlTourDuLichDataSet
            // 
            this.qlTourDuLichDataSet.DataSetName = "QlTourDuLichDataSet";
            this.qlTourDuLichDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tOURBindingSource
            // 
            this.tOURBindingSource.DataMember = "TOUR";
            this.tOURBindingSource.DataSource = this.qlTourDuLichDataSet;
            // 
            // tOURTableAdapter
            // 
            this.tOURTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CTPHIEUNHAP_TOURTableAdapter = null;
            this.tableAdapterManager.DIADANHTableAdapter = null;
            this.tableAdapterManager.DIADIEMTableAdapter = null;
            this.tableAdapterManager.HANHTRINHTableAdapter = null;
            this.tableAdapterManager.HOPDONGTableAdapter = null;
            this.tableAdapterManager.HUONGDANVIENTableAdapter = null;
            this.tableAdapterManager.KHACHHANGTableAdapter = null;
            this.tableAdapterManager.KHACHSANTableAdapter = null;
            this.tableAdapterManager.LOAIKHACHHANGTableAdapter = null;
            this.tableAdapterManager.LOAIKHACHSANTableAdapter = null;
            this.tableAdapterManager.LOAITOURTableAdapter = null;
            this.tableAdapterManager.MANHINHTableAdapter = null;
            this.tableAdapterManager.NGUOIDUNGTableAdapter = null;
            this.tableAdapterManager.NHOMNGUOIDUNGTableAdapter = null;
            this.tableAdapterManager.PHANQUYENTableAdapter = null;
            this.tableAdapterManager.PHIEUNHAPTOURTableAdapter = null;
            this.tableAdapterManager.QUANLINHOMNGUOIDUNGTableAdapter = null;
            this.tableAdapterManager.TOURTableAdapter = this.tOURTableAdapter;
            this.tableAdapterManager.UpdateOrder = LoadTour.QlTourDuLichDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tOURBindingNavigator
            // 
            this.tOURBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tOURBindingNavigator.BindingSource = this.tOURBindingSource;
            this.tOURBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tOURBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tOURBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tOURBindingNavigatorSaveItem});
            this.tOURBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tOURBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tOURBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tOURBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tOURBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tOURBindingNavigator.Name = "tOURBindingNavigator";
            this.tOURBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tOURBindingNavigator.Size = new System.Drawing.Size(408, 25);
            this.tOURBindingNavigator.TabIndex = 0;
            this.tOURBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // tOURBindingNavigatorSaveItem
            // 
            this.tOURBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tOURBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tOURBindingNavigatorSaveItem.Image")));
            this.tOURBindingNavigatorSaveItem.Name = "tOURBindingNavigatorSaveItem";
            this.tOURBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.tOURBindingNavigatorSaveItem.Text = "Save Data";
            this.tOURBindingNavigatorSaveItem.Click += new System.EventHandler(this.tOURBindingNavigatorSaveItem_Click);
            // 
            // maTourLabel
            // 
            maTourLabel.AutoSize = true;
            maTourLabel.Location = new System.Drawing.Point(86, 57);
            maTourLabel.Name = "maTourLabel";
            maTourLabel.Size = new System.Drawing.Size(50, 13);
            maTourLabel.TabIndex = 1;
            maTourLabel.Text = "Ma Tour:";
            // 
            // maTourSpinEdit
            // 
            this.maTourSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaTour", true));
            this.maTourSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maTourSpinEdit.Location = new System.Drawing.Point(195, 54);
            this.maTourSpinEdit.Name = "maTourSpinEdit";
            this.maTourSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maTourSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maTourSpinEdit.TabIndex = 2;
            // 
            // tenTourLabel
            // 
            tenTourLabel.AutoSize = true;
            tenTourLabel.Location = new System.Drawing.Point(86, 83);
            tenTourLabel.Name = "tenTourLabel";
            tenTourLabel.Size = new System.Drawing.Size(54, 13);
            tenTourLabel.TabIndex = 3;
            tenTourLabel.Text = "Ten Tour:";
            // 
            // tenTourTextEdit
            // 
            this.tenTourTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "TenTour", true));
            this.tenTourTextEdit.Location = new System.Drawing.Point(195, 80);
            this.tenTourTextEdit.Name = "tenTourTextEdit";
            this.tenTourTextEdit.Size = new System.Drawing.Size(100, 20);
            this.tenTourTextEdit.TabIndex = 4;
            // 
            // ngayKhoiHanhLabel
            // 
            ngayKhoiHanhLabel.AutoSize = true;
            ngayKhoiHanhLabel.Location = new System.Drawing.Point(86, 109);
            ngayKhoiHanhLabel.Name = "ngayKhoiHanhLabel";
            ngayKhoiHanhLabel.Size = new System.Drawing.Size(87, 13);
            ngayKhoiHanhLabel.TabIndex = 5;
            ngayKhoiHanhLabel.Text = "Ngay Khoi Hanh:";
            // 
            // ngayKhoiHanhDateEdit
            // 
            this.ngayKhoiHanhDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "NgayKhoiHanh", true));
            this.ngayKhoiHanhDateEdit.EditValue = null;
            this.ngayKhoiHanhDateEdit.Location = new System.Drawing.Point(195, 106);
            this.ngayKhoiHanhDateEdit.Name = "ngayKhoiHanhDateEdit";
            this.ngayKhoiHanhDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKhoiHanhDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKhoiHanhDateEdit.Size = new System.Drawing.Size(100, 20);
            this.ngayKhoiHanhDateEdit.TabIndex = 6;
            // 
            // ngayKetThucLabel
            // 
            ngayKetThucLabel.AutoSize = true;
            ngayKetThucLabel.Location = new System.Drawing.Point(86, 135);
            ngayKetThucLabel.Name = "ngayKetThucLabel";
            ngayKetThucLabel.Size = new System.Drawing.Size(81, 13);
            ngayKetThucLabel.TabIndex = 7;
            ngayKetThucLabel.Text = "Ngay Ket Thuc:";
            // 
            // ngayKetThucDateEdit
            // 
            this.ngayKetThucDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "NgayKetThuc", true));
            this.ngayKetThucDateEdit.EditValue = null;
            this.ngayKetThucDateEdit.Location = new System.Drawing.Point(195, 132);
            this.ngayKetThucDateEdit.Name = "ngayKetThucDateEdit";
            this.ngayKetThucDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKetThucDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngayKetThucDateEdit.Size = new System.Drawing.Size(100, 20);
            this.ngayKetThucDateEdit.TabIndex = 8;
            // 
            // giaTreEmLabel
            // 
            giaTreEmLabel.AutoSize = true;
            giaTreEmLabel.Location = new System.Drawing.Point(86, 161);
            giaTreEmLabel.Name = "giaTreEmLabel";
            giaTreEmLabel.Size = new System.Drawing.Size(62, 13);
            giaTreEmLabel.TabIndex = 9;
            giaTreEmLabel.Text = "Gia Tre Em:";
            // 
            // giaTreEmSpinEdit
            // 
            this.giaTreEmSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "GiaTreEm", true));
            this.giaTreEmSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.giaTreEmSpinEdit.Location = new System.Drawing.Point(195, 158);
            this.giaTreEmSpinEdit.Name = "giaTreEmSpinEdit";
            this.giaTreEmSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.giaTreEmSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.giaTreEmSpinEdit.TabIndex = 10;
            // 
            // giaNguoiLonLabel
            // 
            giaNguoiLonLabel.AutoSize = true;
            giaNguoiLonLabel.Location = new System.Drawing.Point(86, 187);
            giaNguoiLonLabel.Name = "giaNguoiLonLabel";
            giaNguoiLonLabel.Size = new System.Drawing.Size(76, 13);
            giaNguoiLonLabel.TabIndex = 11;
            giaNguoiLonLabel.Text = "Gia Nguoi Lon:";
            // 
            // giaNguoiLonSpinEdit
            // 
            this.giaNguoiLonSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "GiaNguoiLon", true));
            this.giaNguoiLonSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.giaNguoiLonSpinEdit.Location = new System.Drawing.Point(195, 184);
            this.giaNguoiLonSpinEdit.Name = "giaNguoiLonSpinEdit";
            this.giaNguoiLonSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.giaNguoiLonSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.giaNguoiLonSpinEdit.TabIndex = 12;
            // 
            // moTaLabel
            // 
            moTaLabel.AutoSize = true;
            moTaLabel.Location = new System.Drawing.Point(86, 213);
            moTaLabel.Name = "moTaLabel";
            moTaLabel.Size = new System.Drawing.Size(40, 13);
            moTaLabel.TabIndex = 13;
            moTaLabel.Text = "Mo Ta:";
            // 
            // moTaTextEdit
            // 
            this.moTaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MoTa", true));
            this.moTaTextEdit.Location = new System.Drawing.Point(195, 210);
            this.moTaTextEdit.Name = "moTaTextEdit";
            this.moTaTextEdit.Size = new System.Drawing.Size(100, 20);
            this.moTaTextEdit.TabIndex = 14;
            // 
            // maLoaiTourLabel
            // 
            maLoaiTourLabel.AutoSize = true;
            maLoaiTourLabel.Location = new System.Drawing.Point(86, 239);
            maLoaiTourLabel.Name = "maLoaiTourLabel";
            maLoaiTourLabel.Size = new System.Drawing.Size(72, 13);
            maLoaiTourLabel.TabIndex = 15;
            maLoaiTourLabel.Text = "Ma Loai Tour:";
            // 
            // maLoaiTourSpinEdit
            // 
            this.maLoaiTourSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaLoaiTour", true));
            this.maLoaiTourSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maLoaiTourSpinEdit.Location = new System.Drawing.Point(195, 236);
            this.maLoaiTourSpinEdit.Name = "maLoaiTourSpinEdit";
            this.maLoaiTourSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maLoaiTourSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maLoaiTourSpinEdit.TabIndex = 16;
            // 
            // maHanhTrinhLabel
            // 
            maHanhTrinhLabel.AutoSize = true;
            maHanhTrinhLabel.Location = new System.Drawing.Point(86, 265);
            maHanhTrinhLabel.Name = "maHanhTrinhLabel";
            maHanhTrinhLabel.Size = new System.Drawing.Size(80, 13);
            maHanhTrinhLabel.TabIndex = 17;
            maHanhTrinhLabel.Text = "Ma Hanh Trinh:";
            // 
            // maHanhTrinhSpinEdit
            // 
            this.maHanhTrinhSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaHanhTrinh", true));
            this.maHanhTrinhSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maHanhTrinhSpinEdit.Location = new System.Drawing.Point(195, 262);
            this.maHanhTrinhSpinEdit.Name = "maHanhTrinhSpinEdit";
            this.maHanhTrinhSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maHanhTrinhSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maHanhTrinhSpinEdit.TabIndex = 18;
            // 
            // maHDVLabel
            // 
            maHDVLabel.AutoSize = true;
            maHDVLabel.Location = new System.Drawing.Point(86, 291);
            maHDVLabel.Name = "maHDVLabel";
            maHDVLabel.Size = new System.Drawing.Size(48, 13);
            maHDVLabel.TabIndex = 19;
            maHDVLabel.Text = "Ma HDV:";
            // 
            // maHDVSpinEdit
            // 
            this.maHDVSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "MaHDV", true));
            this.maHDVSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maHDVSpinEdit.Location = new System.Drawing.Point(195, 288);
            this.maHDVSpinEdit.Name = "maHDVSpinEdit";
            this.maHDVSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maHDVSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maHDVSpinEdit.TabIndex = 20;
            // 
            // anhDaiDienLabel
            // 
            anhDaiDienLabel.AutoSize = true;
            anhDaiDienLabel.Location = new System.Drawing.Point(86, 317);
            anhDaiDienLabel.Name = "anhDaiDienLabel";
            anhDaiDienLabel.Size = new System.Drawing.Size(72, 13);
            anhDaiDienLabel.TabIndex = 21;
            anhDaiDienLabel.Text = "Anh Dai Dien:";
            // 
            // anhDaiDienTextEdit
            // 
            this.anhDaiDienTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "AnhDaiDien", true));
            this.anhDaiDienTextEdit.Location = new System.Drawing.Point(195, 314);
            this.anhDaiDienTextEdit.Name = "anhDaiDienTextEdit";
            this.anhDaiDienTextEdit.Size = new System.Drawing.Size(100, 20);
            this.anhDaiDienTextEdit.TabIndex = 22;
            // 
            // soLuongDuKhachLabel
            // 
            soLuongDuKhachLabel.AutoSize = true;
            soLuongDuKhachLabel.Location = new System.Drawing.Point(86, 343);
            soLuongDuKhachLabel.Name = "soLuongDuKhachLabel";
            soLuongDuKhachLabel.Size = new System.Drawing.Size(103, 13);
            soLuongDuKhachLabel.TabIndex = 23;
            soLuongDuKhachLabel.Text = "So Luong Du Khach:";
            // 
            // soLuongDuKhachSpinEdit
            // 
            this.soLuongDuKhachSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tOURBindingSource, "SoLuongDuKhach", true));
            this.soLuongDuKhachSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.soLuongDuKhachSpinEdit.Location = new System.Drawing.Point(195, 340);
            this.soLuongDuKhachSpinEdit.Name = "soLuongDuKhachSpinEdit";
            this.soLuongDuKhachSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.soLuongDuKhachSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.soLuongDuKhachSpinEdit.TabIndex = 24;
            // 
            // XtraUserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(maTourLabel);
            this.Controls.Add(this.maTourSpinEdit);
            this.Controls.Add(tenTourLabel);
            this.Controls.Add(this.tenTourTextEdit);
            this.Controls.Add(ngayKhoiHanhLabel);
            this.Controls.Add(this.ngayKhoiHanhDateEdit);
            this.Controls.Add(ngayKetThucLabel);
            this.Controls.Add(this.ngayKetThucDateEdit);
            this.Controls.Add(giaTreEmLabel);
            this.Controls.Add(this.giaTreEmSpinEdit);
            this.Controls.Add(giaNguoiLonLabel);
            this.Controls.Add(this.giaNguoiLonSpinEdit);
            this.Controls.Add(moTaLabel);
            this.Controls.Add(this.moTaTextEdit);
            this.Controls.Add(maLoaiTourLabel);
            this.Controls.Add(this.maLoaiTourSpinEdit);
            this.Controls.Add(maHanhTrinhLabel);
            this.Controls.Add(this.maHanhTrinhSpinEdit);
            this.Controls.Add(maHDVLabel);
            this.Controls.Add(this.maHDVSpinEdit);
            this.Controls.Add(anhDaiDienLabel);
            this.Controls.Add(this.anhDaiDienTextEdit);
            this.Controls.Add(soLuongDuKhachLabel);
            this.Controls.Add(this.soLuongDuKhachSpinEdit);
            this.Controls.Add(this.tOURBindingNavigator);
            this.Name = "XtraUserControl1";
            this.Size = new System.Drawing.Size(408, 380);
            ((System.ComponentModel.ISupportInitialize)(this.qlTourDuLichDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tOURBindingNavigator)).EndInit();
            this.tOURBindingNavigator.ResumeLayout(false);
            this.tOURBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maTourSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenTourTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKhoiHanhDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngayKetThucDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaTreEmSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.giaNguoiLonSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.moTaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maLoaiTourSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHanhTrinhSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maHDVSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anhDaiDienTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soLuongDuKhachSpinEdit.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private QlTourDuLichDataSet qlTourDuLichDataSet;
        private System.Windows.Forms.BindingSource tOURBindingSource;
        private QlTourDuLichDataSetTableAdapters.TOURTableAdapter tOURTableAdapter;
        private QlTourDuLichDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tOURBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tOURBindingNavigatorSaveItem;
        private DevExpress.XtraEditors.SpinEdit maTourSpinEdit;
        private DevExpress.XtraEditors.TextEdit tenTourTextEdit;
        private DevExpress.XtraEditors.DateEdit ngayKhoiHanhDateEdit;
        private DevExpress.XtraEditors.DateEdit ngayKetThucDateEdit;
        private DevExpress.XtraEditors.SpinEdit giaTreEmSpinEdit;
        private DevExpress.XtraEditors.SpinEdit giaNguoiLonSpinEdit;
        private DevExpress.XtraEditors.TextEdit moTaTextEdit;
        private DevExpress.XtraEditors.SpinEdit maLoaiTourSpinEdit;
        private DevExpress.XtraEditors.SpinEdit maHanhTrinhSpinEdit;
        private DevExpress.XtraEditors.SpinEdit maHDVSpinEdit;
        private DevExpress.XtraEditors.TextEdit anhDaiDienTextEdit;
        private DevExpress.XtraEditors.SpinEdit soLuongDuKhachSpinEdit;
    }
}
