﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace LoadTour
{
    public partial class XtraUserControl1 : DevExpress.XtraEditors.XtraUserControl
    {
        public XtraUserControl1()
        {
            InitializeComponent();
        }

        private void tOURBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tOURBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.qlTourDuLichDataSet);

        }
    }
}
